import os
import time
import torch
import argparse
import psutil  # For CPU memory tracking
import pandas as pd
from model import SASRec
from utils import *
import random
import sys



def str2bool(s):
    if s not in {'false', 'true'}:
        raise ValueError('Not a valid boolean string')
    return s == 'true'

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', required=True)
parser.add_argument('--train_dir', required=True)
parser.add_argument('--batch_size', default=128, type=int)
parser.add_argument('--lr', default=0.001, type=float)
parser.add_argument('--maxlen', default=200, type=int)
parser.add_argument('--hidden_units', default=50, type=int)
parser.add_argument('--num_blocks', default=2, type=int)
parser.add_argument('--num_epochs', default=500, type=int)
parser.add_argument('--num_heads', default=1, type=int)
parser.add_argument('--dropout_rate', default=0.2, type=float)
parser.add_argument('--l2_emb', default=0.0, type=float)
parser.add_argument('--device', default='cuda', type=str)
parser.add_argument('--inference_only', default=False, type=str2bool)
parser.add_argument('--state_dict_path', default=None, type=str)
parser.add_argument('--eval_mode', choices=['full', 'sample'], default='sample', help="Evaluation mode: 'full' or 'sample'")
parser.add_argument('--early_stopping_patience', type=int, default=8,
                    help='Number of evaluations to wait before early stopping if no improvement')
parser.add_argument('--sample_mode', type=str, default='normal', choices=['normal', 'random','random_chrono'],
                    help='Choose between normal or random sampling strategy in training')

args = parser.parse_args()
if not os.path.isdir(args.dataset + '_' + args.train_dir):
    os.makedirs(args.dataset + '_' + args.train_dir)
with open(os.path.join(args.dataset + '_' + args.train_dir, 'args.txt'), 'w') as f:
    f.write('\n'.join([str(k) + ',' + str(v) for k, v in sorted(vars(args).items(), key=lambda x: x[0])]))
#f.close()

def track_memory_usage():
    """
    Track and return the current GPU and CPU memory usage.
    """
    gpu_mem = torch.cuda.max_memory_allocated() / (1024 ** 3) if torch.cuda.is_available() else 0  # Convert to GB
    cpu_mem = psutil.Process(os.getpid()).memory_info().rss / (1024 ** 3)  # Convert to GB
    return gpu_mem, cpu_mem

def data_partition_xlong(dataset_path):
    def split_sessions(seq):
        return [int(x.strip()) for x in seq.split(",")]

    def load_ratings_df(folder_path):
        train_path = os.path.join(folder_path, 'train_corpus_total_dual.txt')
        test_path = os.path.join(folder_path, 'test_corpus_total_dual.txt')
        train = pd.read_csv(train_path, header=None, sep='\t')
        test = pd.read_csv(test_path, header=None, sep='\t')
        df = pd.DataFrame(np.concatenate([train, test], axis=0))
      
        df[2] = df[2].apply(split_sessions)
        df.apply(lambda x: x[2].extend(split_sessions(str(x[3]))), axis=1)

        df = df[2].values
        df = pd.DataFrame(zip(range(len(df)), df), columns=['uid', 'sid'])
        df = df.explode('sid')
        df['uid'] = df['uid'].astype(int)
        df['sid'] = df['sid'].astype(int)
        return df

    def remove_immediate_repeats(df):
        df_next = df.shift()
        is_not_repeat = (df['uid'] != df_next['uid']) | (df['sid'] != df_next['sid'])
        df = df[is_not_repeat]
        return df

    def filter_triplets(df, min_sc=0, min_uc=0):
        print('Filtering triplets')
        if min_sc > 0:
            item_sizes = df.groupby('sid').size()
            good_items = item_sizes.index[item_sizes >= min_sc]
            df = df[df['sid'].isin(good_items)]

        if min_uc > 0:
            user_sizes = df.groupby('uid').size()
            good_users = user_sizes.index[user_sizes >= min_uc]
            df = df[df['uid'].isin(good_users)]
        return df

    print("Processing xlong dataset...")
    df = load_ratings_df(dataset_path)
    
    # Apply preprocessing steps
    df = remove_immediate_repeats(df)
    df = filter_triplets(df, min_sc=5, min_uc=5)  # Adjust min_sc/min_uc as needed
    
    # Re-index
    user_map = {uid: i+1 for i, uid in enumerate(df['uid'].unique())}
    item_map = {sid: i+1 for i, sid in enumerate(df['sid'].unique())}
    df['uid'] = df['uid'].map(user_map)
    df['sid'] = df['sid'].map(item_map)

    usernum = len(user_map)
    itemnum = len(item_map)

    user_train = {}
    user_valid = {}
    user_test = {}

    user2items = df.groupby('uid')['sid'].apply(list)

    for user in range(1, usernum + 1):
        items = user2items.get(user, [])
        if len(items) < 3:
            user_train[user] = items
            user_valid[user] = []
            user_test[user] = []
        else:
            user_train[user] = items[:-2]
            user_valid[user] = [items[-2]]
            user_test[user] = [items[-1]]

    return [user_train, user_valid, user_test, usernum, itemnum]
def data_partition_foursquare(file_path):
    def load_ratings_df(path):
        df = pd.read_csv(path, sep="\t", header=None)
        df.columns = ['uid', 'venue_id', 'timestamp', 'tz_offset']
        # Sort by timestamp so sequences are chronological
        df = df.sort_values(by=['uid', 'timestamp'])
        return df[['uid', 'venue_id']]

    def remove_immediate_repeats(df):
        df_next = df.shift()
        is_not_repeat = (df['uid'] != df_next['uid']) | (df['venue_id'] != df_next['venue_id'])
        return df[is_not_repeat]

    def filter_triplets(df, min_sc=0, min_uc=0):
        print('Filtering triplets...')
        if min_sc > 0:
            item_sizes = df.groupby('venue_id').size()
            good_items = item_sizes.index[item_sizes >= min_sc]
            df = df[df['venue_id'].isin(good_items)]
        if min_uc > 0:
            user_sizes = df.groupby('uid').size()
            good_users = user_sizes.index[user_sizes >= min_uc]
            df = df[df['uid'].isin(good_users)]
        return df

    print("📦 Processing Foursquare dataset...")
    df = load_ratings_df(file_path)
    
    # Remove duplicates in sequence
    df = remove_immediate_repeats(df)
    
    # Filter out inactive users/items
    df = filter_triplets(df, min_sc=5, min_uc=5)
    
    # Reindex users and items
    user_map = {uid: i+1 for i, uid in enumerate(df['uid'].unique())}
    item_map = {iid: i+1 for i, iid in enumerate(df['venue_id'].unique())}
    df['uid'] = df['uid'].map(user_map)
    df['sid'] = df['venue_id'].map(item_map)

    usernum = len(user_map)
    itemnum = len(item_map)

    # Group by user
    user2items = df.groupby('uid')['sid'].apply(list)

    # Split into train, validation, test
    user_train, user_valid, user_test = {}, {}, {}
    for user in range(1, usernum + 1):
        items = user2items.get(user, [])
        if len(items) < 3:
            user_train[user] = items
            user_valid[user] = []
            user_test[user] = []
        else:
            user_train[user] = items[:-2]
            user_valid[user] = [items[-2]]
            user_test[user] = [items[-1]]

    return [user_train, user_valid, user_test, usernum, itemnum]
def format_duration(seconds):
    """Convert seconds to human-readable format with days, hours, minutes, seconds."""
    days, remainder = divmod(seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    parts = []
    if days > 0:
        parts.append(f"{int(days)} day{'s' if days != 1 else ''}")
    if hours > 0:
        parts.append(f"{int(hours)} hour{'s' if hours != 1 else ''}")
    if minutes > 0:
        parts.append(f"{int(minutes)} minute{'s' if minutes != 1 else ''}")
    if seconds > 0 or not parts:  # Show seconds if it's the only unit
        parts.append(f"{seconds:.2f} second{'s' if seconds != 1 else ''}")
    
    return ' '.join(parts)

if __name__ == '__main__':
    np.random.seed(42)
    #torch.manual_seed(42)
    if args.dataset == 'ml-1m' or args.dataset.startswith('synthetic') or args.dataset =='ml-100k':
        # Only for ML-1M do we build a user↔item index
        u2i_index, i2u_index = build_index(args.dataset)
        dataset = data_partition(args.dataset)
    

    elif args.dataset == 'xlong':
        # For xlong, skip build_index() (because there is no data/xlong.txt)
        u2i_index, i2u_index = None, None
        
        folder_path = '/home/zik/SASRec.pytorch/data/xlong'
        dataset = data_partition_xlong(folder_path)
    elif args.dataset =='foursquare':
        # For xlong, skip build_index() (because there is no data/xlong.txt)
        u2i_index, i2u_index = None, None
        
        folder_path = '/home/zik/SASRec.pytorch_LinRec/data/fdata.txt'
        dataset = data_partition_foursquare(folder_path)

    else:
        raise ValueError("Unsupported dataset")


    [user_train, user_valid, user_test, usernum, itemnum] = dataset
    num_users = usernum
    num_items = itemnum
    num_interactions = (
        sum(len(seq) for seq in user_train.values())
      + sum(len(seq) for seq in user_valid.values())
      + sum(len(seq) for seq in user_test.values())
    )

    print(f"Dataset = {args.dataset}")
    print(f"  # users         = {num_users}")
    print(f"  # items         = {num_items}")
    print(f"  # interactions  = {num_interactions}")
    print(f"  # Sequence length = {args.maxlen}")
    num_batch = (len(user_train) - 1) // args.batch_size + 1
   
    user_train = dataset[0]  # Assuming dataset returned as [user_train, user_valid, user_test, usernum, itemnum]
    avg_seq_len = sum(len(seq) for seq in user_train.values()) / len(user_train)
    print(f"  # Average sequence length = {avg_seq_len:.2f}")
    if args.sample_mode == 'normal':
        sampler_func = sample_function
    elif args.sample_mode == 'random':
        sampler_func = sample_random_function
    elif args.sample_mode =='random_chrono':
        sampler_func = sample_random_chrono_function
    else:
        raise ValueError("Invalid --sampler argument")
    sampler = WarpSampler(user_train, usernum, itemnum, batch_size=args.batch_size, maxlen=args.maxlen, n_workers=3,sampler_func = sampler_func)
    

    model = SASRec(usernum, itemnum, args).to(args.device)
    

    for name, param in model.named_parameters():
        try:
            torch.nn.init.xavier_normal_(param.data)
        except:
            pass

    model.pos_emb.weight.data[0, :] = 0
    model.item_emb.weight.data[0, :] = 0
    
    model.train()
    
    
    if args.state_dict_path is not None:
        model.load_state_dict(torch.load(args.state_dict_path, map_location=torch.device(args.device)))

    if args.inference_only:
        model.eval()
        t_test = evaluate(model, dataset, args)
        print('test (NDCG@10: %.4f, HR@10: %.4f)' % (t_test[0], t_test[1]))

    bce_criterion = torch.nn.BCEWithLogitsLoss()
    
    adam_optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.98))
    best_val_ndcg, best_val_hr = 0.0, 0.0
    best_val_ndcg20, best_val_hr20 = 0.0, 0.0
    best_test_ndcg, best_test_hr = 0.0, 0.0
    T = 0.0
    t0 = time.time()
    train_times = []
    test_times = []
    best_test_metrics = None
    epoch_times = 0.0  # Store cumulative time
    log_path = os.path.join(args.dataset + '_' + args.train_dir, 'log.txt')
    log_f = open(log_path, 'w')
    patience = args.early_stopping_patience
    patience_counter = 0
    test_results = []
    best_overall_test_ndcg10 = -float('inf')
    best_overall_test_ndcg20 = -float('inf')
    best_overall_test_metrics = None
    best_overall_test_epoch   = 0
    for epoch in range(1, args.num_epochs + 1):
        
        if args.inference_only: break # just to decrease identition
        train_start_time = time.time()
        for step in range(num_batch): # tqdm(range(num_batch), total=num_batch, ncols=70, leave=False, unit='b'):
            u, seq, pos, neg = sampler.next_batch() # tuples to ndarray
            u, seq, pos, neg = np.array(u), np.array(seq), np.array(pos), np.array(neg)
            
            pos_logits, neg_logits = model(u, seq, pos, neg)
            pos_labels, neg_labels = torch.ones(pos_logits.shape, device=args.device), torch.zeros(neg_logits.shape, device=args.device)
            # print("\neye ball check raw_logits:"); print(pos_logits); print(neg_logits) # check pos_logits > 0, neg_logits < 0
            adam_optimizer.zero_grad()
            indices = np.where(pos != 0)
            loss = bce_criterion(pos_logits[indices], pos_labels[indices])
            loss += bce_criterion(neg_logits[indices], neg_labels[indices])
            for param in model.item_emb.parameters(): loss += args.l2_emb * torch.norm(param)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            adam_optimizer.step()
        print("loss in epoch {} : {}".format(epoch, loss.item())) # expected 0.4~0.6 after init few epochs

        train_epoch_time = time.time() - train_start_time
        train_times.append(train_epoch_time)
        best_model_state = None
        #if epoch % 20 == 0:
            # test_start_time = time.time()
            # model.eval()
            # t1 = time.time() - t0
            # T += t1
            # print('Evaluating', end='')
            # t_test = evaluate(model, dataset, args)
            # test_results.append(t_test)
            # t_valid = evaluate_valid(model, dataset, args)
            # test_epoch_time = (time.time() - test_start_time) 
            # test_times.append(test_epoch_time)
            # print('epoch:%d, time: %f(s), valid (NDCG@10: %.4f, Recall@10: %.4f, NDCG@20: %.4f, Recall@20: %.4f), '
            # 'test (NDCG@10: %.4f, Recall@10: %.4f, NDCG@20: %.4f, Recall@20: %.4f)'
            # % (epoch, T, t_valid[0], t_valid[1], t_valid[2], t_valid[3], t_test[0], t_test[1], t_test[2], t_test[3]))
        if epoch % 50 == 0:
            test_start_time = time.time()
            model.eval()

            #print("\n--- Evaluation Timing ---")
            #eval_valid_start = time.time()
            t_valid = evaluate_valid(model, dataset, args)
            #eval_valid_time = time.time() - eval_valid_start
            #print(f"Validation time: {eval_valid_time:.2f}s")

            #eval_test_start = time.time()
            t_test = evaluate(model, dataset, args)
            #eval_test_time = time.time() - eval_test_start
            #print(f"Test time: {eval_test_time:.2f}s")
            #print(f"Total evaluation time: {eval_valid_time + eval_test_time:.2f}s")
            #print("--- End Evaluation Timing ---\n")

            test_epoch_time = time.time() - test_start_time
            test_times.append(test_epoch_time)

            test_results.append(t_test)
            print('epoch:%d, time: %f(s), valid (NDCG@10: %.4f, Recall@10: %.4f, NDCG@20: %.4f, Recall@20: %.4f), '
                'test (NDCG@10: %.4f, Recall@10: %.4f, NDCG@20: %.4f, Recall@20: %.4f)'
                % (epoch, T, t_valid[0], t_valid[1], t_valid[2], t_valid[3], t_test[0], t_test[1], t_test[2], t_test[3]))
    
            
            
            if t_valid[0] > best_val_ndcg or t_valid[2] > best_val_ndcg20:
                best_val_ndcg = max(t_valid[0], best_val_ndcg)
                best_val_ndcg20 = max(t_valid[2],best_val_ndcg20)
                best_model_state = copy.deepcopy(model.state_dict())
                best_test_ndcg = t_test[0]
                best_test_hr = t_test[1]
                best_epoch = epoch
                best_test_metrics = t_test
                patience_counter = 0  # reset counter
                folder = args.dataset + '_' + args.train_dir
            if t_test[0] > best_overall_test_ndcg10 or \
                t_test[2] > best_overall_test_ndcg20:
                    best_overall_test_ndcg10 = max(best_overall_test_ndcg10, t_test[0])
                    best_overall_test_ndcg20 = max(best_overall_test_ndcg20, t_test[2])
                    best_overall_test_metrics = t_test
                    best_overall_test_epoch   = epoch
                    
            else:
                patience_counter += 1
                print(f"  --> No improvement. Patience: {patience_counter}/{patience}")
            if patience_counter >= patience:
                print(f"Early stopping triggered at epoch {epoch}. Best epoch was {best_epoch}.")
                break

    final_ndcg10, final_hr10, final_ndcg20, final_hr20 = best_test_metrics
    print(
    f"Test‐driven best at epoch {best_overall_test_epoch}: "
    f"NDCG@10={best_overall_test_metrics[0]:.4f}, "
    f"Recall@10={best_overall_test_metrics[1]:.4f}, "
    f"NDCG@20={best_overall_test_metrics[2]:.4f}, "
    f"Recall@20={best_overall_test_metrics[3]:.4f}"
)


        # if epoch == args.num_epochs:
        #     folder = args.dataset + '_' + args.train_dir
        #     fname = 'SASRec.epoch={}.lr={}.layer={}.head={}.hidden={}.maxlen={}.pth'
        #     fname = fname.format(args.num_epochs, args.lr, args.num_blocks, args.num_heads, args.hidden_units, args.maxlen)
        #     torch.save(model.state_dict(), os.path.join(folder, fname))
    total_train_time = sum(train_times)
    total_test_time = sum(test_times)
    # all_ndcg10 = [res[0] for res in test_results]
    # all_hr10   = [res[1] for res in test_results]
    # all_ndcg20 = [res[2] for res in test_results]
    # all_hr20   = [res[3] for res in test_results]

    # print("\n📊 Best Test Metrics Across All Epochs:")
    # print(f"Best NDCG@10:  {max(all_ndcg10):.4f}")
    # print(f"Best Recall@10:    {max(all_hr10):.4f}")
    # print(f"Best NDCG@20:  {max(all_ndcg20):.4f}")
    # print(f"Best Recall@20:    {max(all_hr20):.4f}")    
    average_train_time = total_train_time / args.num_epochs if args.num_epochs > 0 else 0
    average_test_time = total_test_time / args.num_epochs if args.num_epochs > 0 else 0

    print(f"Total time used: {format_duration(total_train_time + total_test_time)}")
    print(f"Training time: {format_duration(total_train_time)} (avg: {format_duration(average_train_time)} per epoch)")
    print(f"Testing time: {format_duration(total_test_time)} (avg: {format_duration(average_test_time)} per epoch)")
    print(f"Average Train Time per Epoch: {average_train_time:.2f} seconds")
    print(f"Average Test Time per Epoch: {average_test_time:.2f} seconds")
    gpu_mem, cpu_mem = track_memory_usage()
    print(f"Final Memory Usage - GPU: {gpu_mem:.2f} GB, CPU: {cpu_mem:.2f} GB")
    
    #f.close()
    log_f.close()
    sampler.close()
    print("Done")


