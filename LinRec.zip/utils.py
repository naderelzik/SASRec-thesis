import sys
import copy

import random
import numpy as np
from collections import defaultdict
from multiprocessing import Process, Queue


def build_index(dataset_name):

    ui_mat = np.loadtxt('data/%s.txt' % dataset_name, dtype=np.int32)

    n_users = ui_mat[:, 0].max()
    n_items = ui_mat[:, 1].max()

    u2i_index = [[] for _ in range(n_users + 1)]
    i2u_index = [[] for _ in range(n_items + 1)]

    for ui_pair in ui_mat:
        u2i_index[ui_pair[0]].append(ui_pair[1])
        i2u_index[ui_pair[1]].append(ui_pair[0])

    return u2i_index, i2u_index

# sampler for batch generation
def random_neq(l, r, s):
    t = np.random.randint(l, r)
    while t in s:
        t = np.random.randint(l, r)
    return t

"""THIS IS THE TRUE SAMPLE WITH LAST MAXLEN ITEMS BUT SON WANTED ME TO DO ANOTHER TYPE OF SAMPLING I WILL DO IT AFTER THIS"""
def sample_function(user_train, usernum, itemnum, batch_size, maxlen, result_queue, SEED):
    

    def sample(uid):

        while len(user_train[uid]) <= 1: user = np.random.randint(1, usernum + 1)

        seq = np.zeros([maxlen], dtype=np.int32)
        pos = np.zeros([maxlen], dtype=np.int32)
        neg = np.zeros([maxlen], dtype=np.int32)
        #print("The uid is",uid)
        nxt = user_train[uid][-1]
        idx = maxlen - 1

        ts = set(user_train[uid])
        for i in reversed(user_train[uid][:-1]):
            seq[idx] = i
            pos[idx] = nxt
            if nxt != 0: neg[idx] = random_neq(1, itemnum + 1, ts)
            nxt = i
            idx -= 1
            if idx == -1: break



        
        return (uid, seq, pos, neg)

    np.random.seed(SEED)
    uids = np.arange(1, usernum+1, dtype=np.int32)
    counter = 0
    while True:
        if counter % usernum == 0:
            np.random.shuffle(uids)
        one_batch = []
        for i in range(batch_size):
            one_batch.append(sample(uids[counter % usernum]))
            counter += 1
        result_queue.put(zip(*one_batch))



def sample_random_function(user_train, usernum, itemnum, batch_size, maxlen, result_queue, SEED):
    # 1) Create *local* RNGs
    np_rng = np.random.RandomState(SEED)
    py_rng = random.Random(SEED)

    def random_neq(low, high, banned_set):
        """Draw from [low, high) but avoid items in banned_set."""
        while True:
            x = py_rng.randrange(low, high)
            if x not in banned_set:
                return x

    def sample(uid):
        # If user too short, pick another uid
        while len(user_train[uid]) <= 1:
            uid = np_rng.randint(1, usernum + 1)

        user_seq = user_train[uid][:-1]
        seq_len  = len(user_seq)

        seq = np.zeros(maxlen, dtype=np.int32)
        pos = np.zeros(maxlen, dtype=np.int32)
        neg = np.zeros(maxlen, dtype=np.int32)

        ts = set(user_train[uid])

        if seq_len >= maxlen:
            # draw maxlen distinct indices, keep order
            sampled_idxs = np_rng.choice(seq_len, maxlen, replace=False)
            sampled_idxs.sort()
            for i, idx in enumerate(sampled_idxs):
                seq[i] = user_seq[idx]
        else:
            # pad front
            start_idx = maxlen - seq_len
            for i, item in enumerate(user_seq):
                seq[start_idx + i] = item

        # build pos/neg
        for i in range(maxlen - 1):
            pos[i] = seq[i+1]
            if pos[i] != 0:
                neg[i] = random_neq(1, itemnum + 1, ts)
        pos[-1] = 0

        return uid, seq, pos, neg

    # 2) Use that same np_rng for shuffling your uid array
    uids = np.arange(1, usernum + 1, dtype=np.int32)
    counter = 0

    while True:
        if counter % usernum == 0:
            np_rng.shuffle(uids)

        one_batch = []
        for _ in range(batch_size):
            uid = uids[counter % usernum]
            one_batch.append(sample(uid))
            counter += 1

        # unzip and put into queue
        result_queue.put(zip(*one_batch))



def sample_random_chrono_function(User, usernum, itemnum, batch_size, maxlen, result_queue, SEED):
    # 1) dedicated RNGs
    np_rng = np.random.RandomState(SEED)
    py_rng = random.Random(SEED)

    def random_neq(low, high, banned_set):
        """Draw from [low, high) but avoid items in banned_set."""
        while True:
            x = py_rng.randrange(low, high)
            if x not in banned_set:
                return x

    def sample(uid):
        user_seq = User[uid]
        seq_len  = len(user_seq)

        # 2) pick window of size maxlen+1
        window_size = maxlen + 1
        if seq_len <= window_size:
            window = user_seq[-window_size:] if seq_len > window_size else user_seq[:]
        else:
            max_start = seq_len - window_size
            start     = np_rng.randint(0, max_start + 1)
            window    = user_seq[start : start + window_size]

        # 3) left-pad if needed
        if len(window) < window_size:
            pad_len = window_size - len(window)
            window = [0]*pad_len + window

        # 4) build seq, pos, neg arrays
        seq = np.zeros(maxlen, dtype=np.int32)
        pos = np.zeros(maxlen, dtype=np.int32)
        neg = np.zeros(maxlen, dtype=np.int32)

        ts = set(user_seq)
        for i in range(maxlen):
            # tokens & next-item
            seq[i] = window[i]
            pos[i] = window[i+1] if i+1 < len(window) else 0

            # negative sampling
            neg[i] = random_neq(1, itemnum+1, ts)

        return uid, seq, pos, neg

    # 5) main loop, deterministic uid sampling
    uids = np.arange(1, usernum+1, dtype=np.int32)
    counter = 0

    while True:
        # reshuffle uids each epoch
        if counter % usernum == 0:
            np_rng.shuffle(uids)

        batch = []
        for _ in range(batch_size):
            uid = uids[counter % usernum]
            batch.append(sample(uid))
            counter += 1

        u, s, p, n = zip(*batch)
        result_queue.put((np.array(u), np.stack(s), np.stack(p), np.stack(n)))




class WarpSampler(object):
    def __init__(self, User, usernum, itemnum, batch_size=64, maxlen=10, n_workers=1,sampler_func = None):
        self.result_queue = Queue(maxsize=n_workers * 10)
        self.processors = []
        
        for i in range(n_workers):
            self.processors.append(
                Process(target=sampler_func, args=(User,
                                                      usernum,
                                                      itemnum,
                                                      batch_size,
                                                      maxlen,
                                                      self.result_queue,
                                                      np.random.randint(2e9)
                                                      )))
            self.processors[-1].daemon = True
            self.processors[-1].start()

    def next_batch(self):
        return self.result_queue.get()

    def close(self):
        for p in self.processors:
            p.terminate()
            p.join()


# train/val/test data generation
def data_partition(fname):
    usernum = 0
    itemnum = 0
    User = defaultdict(list)
    user_train = {}
    user_valid = {}
    user_test = {}
    # assume user/item index starting from 1
    f = open('data/%s.txt' % fname, 'r')
    for line in f:
        u, i = line.rstrip().split(' ')
        u = int(u)
        i = int(i)
        usernum = max(u, usernum)
        itemnum = max(i, itemnum)
        User[u].append(i)

    for user in User:
        nfeedback = len(User[user])
        if nfeedback < 3:
            user_train[user] = User[user]
            user_valid[user] = []
            user_test[user] = []
        else:
            user_train[user] = User[user][:-2]
            user_valid[user] = []
            user_valid[user].append(User[user][-2])
            user_test[user] = []
            user_test[user].append(User[user][-1])
    #print("Length of the whole sequence is",len(User))
    return [user_train, user_valid, user_test, usernum, itemnum]

# TODO: merge evaluate functions for test and val set

#Evaluate on test set
def evaluate(model, dataset, args):
    [train, valid, test, usernum, itemnum] = copy.deepcopy(dataset)

    NDCG = 0.0
    HT = 0.0
    NDCG_20 = 0.0
    HT_20 = 0.0
    valid_user = 0.0

    if usernum > 10000:
        users = random.sample(range(1, usernum + 1), 10000)
    else:
        users = range(1, usernum + 1)

    for u in users:
        if len(train[u]) < 1 or len(test[u]) < 1:
            continue

        seq = np.zeros([args.maxlen], dtype=np.int32)
        idx = args.maxlen - 1
        seq[idx] = valid[u][0]
        idx -= 1
        for i in reversed(train[u]):
            seq[idx] = i
            idx -= 1
            if idx == -1:
                break
        rated = set(train[u])
        rated.add(0)
        #Negative sampling of 100
        if args.eval_mode == 'sample':
            if args.dataset in ['ml-1m', 'synthetic_two_patterns_no_noise','synthetic_two_patterns_begin_noise','synthetic_two_patterns_mid_noise','synthetic_two_patterns_end_noise','ml-100k','foursquare']:
                num_samples = 100
            else:
                num_samples = 10000
            item_idx = [test[u][0]]
            for _ in range(num_samples):
                t = np.random.randint(1, itemnum + 1)
                while t in rated:
                    t = np.random.randint(1, itemnum + 1)
                item_idx.append(t)
        elif args.eval_mode == 'full':
            #Evaluating on whole item set
            item_idx = [i for i in range(1, itemnum + 1) if i not in rated]
            item_idx.insert(0, test[u][0])  # Ensure the test item is the first item
        


        predictions = -model.predict(*[np.array(l) for l in [[u], [seq], item_idx]])
        predictions = predictions[0]

        rank = predictions.argsort().argsort()[0].item()

        valid_user += 1

        # Calculate Hit@10 and NDCG@10
        if rank < 10:
            NDCG += 1 / np.log2(rank + 2)
            HT += 1
        if rank < 20:
            NDCG_20 += 1 / np.log2(rank + 2)
            HT_20 += 1

        if valid_user % 100 == 0:
            print('.', end="")
            sys.stdout.flush()

    return NDCG / valid_user, HT / valid_user, NDCG_20/ valid_user, HT_20/ valid_user


# Evaluate on val set
def evaluate_valid(model, dataset, args):
    [train, valid, test, usernum, itemnum] = copy.deepcopy(dataset)

    NDCG = 0.0
    valid_user = 0.0
    NDCG_20 = 0.0
    HT_20 = 0.0
    HT = 0.0

    if usernum > 10000:
        users = random.sample(range(1, usernum + 1), 10000)
    else:
        users = range(1, usernum + 1)

    for u in users:
        if len(train[u]) < 1 or len(valid[u]) < 1:
            continue

        seq = np.zeros([args.maxlen], dtype=np.int32)
        idx = args.maxlen - 1
        for i in reversed(train[u]):
            seq[idx] = i
            idx -= 1
            if idx == -1:
                break

        rated = set(train[u])
        rated.add(0)
        item_idx = [valid[u][0]]  # Validation item
        for _ in range(100):
            t = np.random.randint(1, itemnum + 1)
            while t in rated:
                t = np.random.randint(1, itemnum + 1)
            item_idx.append(t)

        predictions = -model.predict(*[np.array(l) for l in [[u], [seq], item_idx]])
        predictions = predictions[0]

        rank = predictions.argsort().argsort()[0].item()

        valid_user += 1

        # Calculate Hit@10 and NDCG@10
        if rank < 10:
            NDCG += 1 / np.log2(rank + 2)
            HT += 1
        if rank < 20:
            NDCG_20 += 1 / np.log2(rank + 2)
            HT_20 += 1
 

        if valid_user % 100 == 0:
            print('.', end="")
            sys.stdout.flush()

    return NDCG / valid_user, HT / valid_user, NDCG_20/valid_user, HT_20/valid_user


