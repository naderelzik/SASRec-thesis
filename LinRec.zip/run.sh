#!/bin/bash
#SBATCH --job-name=Linendnoise
#SBATCH --mail-type=ALL
#SBATCH --partition=STUD
#SBATCH --gres=gpu:1

# === Configuration ===
DATASET="synthetic_two_patterns_end_noise"
MAXLEN_LIST=(45 100 200 400 600)
BASE_DIR="/home/zik/SASRec.pytorch_LinRec/randomchronomaxlen"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")  # Get current timestamp
LOG_DIR="${BASE_DIR}/${DATASET}_${TIMESTAMP}"  # Unique directory per run

# === Create log directory ===
mkdir -p "$LOG_DIR"

# === Loop through maxlen values ===
for MAXLEN in "${MAXLEN_LIST[@]}"; do
    LOG_FILE="${LOG_DIR}/${DATASET}_${MAXLEN}.log"
    ERR_FILE="${LOG_DIR}/${DATASET}_${MAXLEN}.err"

    echo "Running maxlen=${MAXLEN} — logs: $LOG_FILE"

    srun --output="$LOG_FILE" --error="$ERR_FILE" \
    python main.py \
        --dataset=$DATASET \
        --train_dir=default \
        --num_heads=4 \
        --maxlen=$MAXLEN \
        --eval_mode=sample \
        --sample_mode=random_chrono \
        --hidden_units=100 \
        --num_epochs=200 \
        --num_blocks=1 \
        --dropout_rate=0.2 \
        --device=cuda
done