# #Best Enhanced code (hope to be)
import torch
import torch.nn as nn
import torch.nn.functional as F



# class LinearAttention(nn.Module):
#     """
#     Elementwise-feature-map linear causal attention (O(B*H*L*D) memory/time).
#     Kernel: phi(x) = elu(x) + 1 (positive).
#     """
#     def __init__(self, hidden_units, num_heads, dropout_rate, eps=1e-6):
#         super().__init__()
#         assert hidden_units % num_heads == 0
#         self.hidden_units = hidden_units
#         self.num_heads = num_heads
#         self.head_dim = hidden_units // num_heads
#         self.eps = eps

#         # single combined projection for speed
#         self.qkv = nn.Linear(hidden_units, 3 * hidden_units, bias=True)
#         self.out = nn.Linear(hidden_units, hidden_units)
#         self.out_dropout = nn.Dropout(dropout_rate)
#         self.layer_norm = nn.LayerNorm(hidden_units, eps=1e-8)

#         # choose kernel: positive and fast
#         self.feature_map = lambda x: F.elu(x) + 1.0

#     def forward(self, x, attention_mask=None):
#         # x: [B, L, hidden]
#         B, L, _ = x.shape
#         H = self.num_heads
#         D = self.head_dim

#         # qkv: [B, L, 3*H*D] -> split
#         qkv = self.qkv(x)  # (B, L, 3*hidden)
#         q, k, v = qkv.chunk(3, dim=-1)

#         # reshape to [B, H, L, D]
#         def reshape_for_heads(t):
#             t = t.view(B, L, H, D).permute(0, 2, 1, 3).contiguous()
#             return t  # [B, H, L, D]

#         q = reshape_for_heads(q)
#         k = reshape_for_heads(k)
#         v = reshape_for_heads(v)

#         # feature map -> positive
#         q_feat = self.feature_map(q)   # [B,H,L,D]
#         k_feat = self.feature_map(k)   # [B,H,L,D]

#         # if attention_mask is provided (B, L) with 1 for valid, 0 for pad
#         if attention_mask is not None:
#             # expand mask to [B,1,L,1]
#             am = attention_mask.view(B, 1, L, 1).to(q_feat.dtype)
#             k_feat = k_feat * am
#             v = v * am

#         # cumulative sums across sequence dimension (causal)
#         # S_t = sum_{i<=t} (k_feat[i] * v[i])   <- elementwise product then cumsum
#         kv_elem = k_feat * v              # [B,H,L,D]
#         kv_cumsum = kv_elem.cumsum(dim=2) # [B,H,L,D]

#         # denom_cumsum = sum_{i<=t} k_feat[i]   -> used for normalizer (scalar per position)
#         k_cumsum = k_feat.cumsum(dim=2)   # [B,H,L,D]

#         # numerator = q_feat * kv_cumsum -> [B,H,L,D]
#         numerator = q_feat * kv_cumsum

#         # denom = q_feat * k_cumsum -> sum over D -> scalar per position
#         denom = (q_feat * k_cumsum).sum(dim=-1, keepdim=True)  # [B,H,L,1]

#         # context per head: numerator / (denom + eps)  -> [B,H,L,D]
#         context = numerator / (denom + self.eps)

#         # merge heads -> [B, L, H*D]
#         context = context.permute(0, 2, 1, 3).contiguous().view(B, L, H * D)

#         # final projection + residual & layernorm (caller may want pre/post norm)
#         out = self.out(context)
#         out = self.out_dropout(out)
#         out = self.layer_norm(out + x)
#         return out

import torch
import torch.nn as nn
import torch.nn.functional as F

class LinearAttention(nn.Module):
    def __init__(self, hidden_units, num_heads, dropout_rate=0.0, eps=1e-6, chunk_size=64):
        super().__init__()
        assert hidden_units % num_heads == 0, "hidden_units must be divisible by num_heads"
        self.hidden_units = hidden_units
        self.num_heads = num_heads
        self.head_dim = hidden_units // num_heads
        self.eps = eps
        self.chunk_size = int(chunk_size)

        # fused qkv projection
        self.qkv = nn.Linear(hidden_units, 3 * hidden_units, bias=True)
        self.out = nn.Linear(hidden_units, hidden_units)
        self.out_dropout = nn.Dropout(dropout_rate)
        self.layer_norm = nn.LayerNorm(hidden_units, eps=1e-8)

        # positive feature map
        self.feature_map = lambda x: F.elu(x) + 1.0

    def forward(self, x, attention_mask=None):
        # x: [B, L, HIDDEN]
        B, L, HIDDEN = x.shape
        H = self.num_heads
        D = self.head_dim
        device = x.device
        dtype = x.dtype

        # fused qkv then split
        qkv = self.qkv(x)                # [B, L, 3*HIDDEN]
        q, k, v = qkv.chunk(3, dim=-1)   # each [B, L, HIDDEN]

        # reshape to [B*H, L, D] (reduces permutes & kernel launches)
        def to_bh(t):
            t = t.view(B, L, H, D).permute(0, 2, 1, 3).contiguous()
            return t.view(B * H, L, D)

        q = to_bh(q); k = to_bh(k); v = to_bh(v)

        q_feat = self.feature_map(q)    # [B*H, L, D]
        k_feat = self.feature_map(k)    # [B*H, L, D]

        if attention_mask is not None:
            # attention_mask: [B, L] with 1 valid, 0 pad
            am = attention_mask.view(B, 1, L).expand(B, H, L).contiguous().view(B * H, L).to(dtype)
            am = am.unsqueeze(-1)
            k_feat = k_feat * am
            v = v * am

        bh = B * H
        out_chunks = []
        prefix_kv_sum = torch.zeros(bh, D, device=device, dtype=dtype)
        prefix_k_sum = torch.zeros(bh, D, device=device, dtype=dtype)
        chunk = max(1, min(self.chunk_size, L))

        for start in range(0, L, chunk):
            end = min(L, start + chunk)
            q_c = q_feat[:, start:end, :]   # [bh, chunk, D]
            k_c = k_feat[:, start:end, :]
            v_c = v[:, start:end, :]

            kv_elem = k_c * v_c                    # [bh, chunk, D]
            kv_local_cumsum = kv_elem.cumsum(dim=1)
            k_local_cumsum = k_c.cumsum(dim=1)

            kv_cumsum = kv_local_cumsum + prefix_kv_sum.unsqueeze(1)
            k_cumsum = k_local_cumsum + prefix_k_sum.unsqueeze(1)

            numer = q_c * kv_cumsum
            denom = (q_c * k_cumsum).sum(dim=-1, keepdim=True)
            ctx_chunk = numer / (denom + self.eps)
            out_chunks.append(ctx_chunk)

            prefix_kv_sum = prefix_kv_sum + kv_elem.sum(dim=1)
            prefix_k_sum = prefix_k_sum + k_c.sum(dim=1)

        context = torch.cat(out_chunks, dim=1)                       # [bh, L, D]
        context = context.view(B, H, L, D).permute(0, 2, 1, 3).contiguous().view(B, L, H * D)

        out = self.out(context)
        out = self.out_dropout(out)
        out = self.layer_norm(out + x)
        return out


class PointWiseFeedForward(nn.Module):
    def __init__(self, hidden_units, dropout_rate, intermediate_units=None):
        super(PointWiseFeedForward, self).__init__()
        if intermediate_units is None:
            intermediate_units = hidden_units * 4
        self.fc1 = nn.Linear(hidden_units, intermediate_units)
        self.activation = nn.ReLU()
        self.dropout = nn.Dropout(dropout_rate)
        self.fc2 = nn.Linear(intermediate_units, hidden_units)

    def forward(self, x):
        residual = x
        out = self.fc1(x)
        out = self.activation(out)
        out = self.dropout(out)
        out = self.fc2(out)
        out = self.dropout(out)
        return out + residual


# class SASRec(nn.Module):
#     def __init__(self, user_num, item_num, args):
#         super(SASRec, self).__init__()
#         self.item_num = item_num
#         self.dev = args.device

#         # Embedding layers
#         self.item_emb = nn.Embedding(item_num + 1, args.hidden_units, padding_idx=0)
#         self.pos_emb = nn.Embedding(args.maxlen + 1, args.hidden_units, padding_idx=0)
#         self.emb_dropout = nn.Dropout(p=args.dropout_rate)

#         # Transformer blocks
#         self.attention_layernorms = nn.ModuleList()
#         self.attention_layers = nn.ModuleList()
#         self.forward_layernorms = nn.ModuleList()
#         self.forward_layers = nn.ModuleList()

#         for _ in range(args.num_blocks):
#             self.attention_layernorms.append(nn.LayerNorm(args.hidden_units, eps=1e-12))
#             self.attention_layers.append(LinearAttention(args.hidden_units, args.num_heads, args.dropout_rate))
#             self.forward_layernorms.append(nn.LayerNorm(args.hidden_units, eps=1e-12))
#             self.forward_layers.append(PointWiseFeedForward(args.hidden_units, args.dropout_rate))

#         self.last_layernorm = nn.LayerNorm(args.hidden_units, eps=1e-12)

#     def log2feats(self, log_seqs):
#         # Convert numpy to tensor and move to device
#         log_seqs = torch.from_numpy(log_seqs).long().to(self.dev)
#         seqs = self.item_emb(log_seqs) * (self.item_emb.embedding_dim ** 0.5)

#         # Positional encoding: sequential positions 1..L
#         positions = torch.arange(log_seqs.size(1), device=self.dev).unsqueeze(0).expand(log_seqs.size(0), -1) + 1
#         seqs = seqs + self.pos_emb(positions)
#         seqs = self.emb_dropout(seqs)

#         # Transformer blocks
#         for ln1, attn, ln2, fwd in zip(
#             self.attention_layernorms, self.attention_layers,
#             self.forward_layernorms, self.forward_layers
#         ):
#             seqs = ln1(seqs)
#             seqs = attn(seqs)  # causal linear attention
#             seqs = ln2(seqs)
#             seqs = fwd(seqs)

#         return self.last_layernorm(seqs)


#     def forward(self, user_ids, log_seqs, pos_seqs, neg_seqs):
#         log_feats = self.log2feats(log_seqs)

#         pos_seqs = torch.from_numpy(pos_seqs).long().to(self.dev)
#         neg_seqs = torch.from_numpy(neg_seqs).long().to(self.dev)

        

#         pos_embs = self.item_emb(pos_seqs)
#         neg_embs = self.item_emb(neg_seqs)

#         pos_logits = (log_feats * pos_embs).sum(dim=-1)
#         neg_logits = (log_feats * neg_embs).sum(dim=-1)
#         return pos_logits, neg_logits

#     def predict(self, user_ids, log_seqs, item_indices):
#         log_feats = self.log2feats(log_seqs)
#         final_feat = log_feats[:, -1, :]
#         item_embs = self.item_emb(torch.LongTensor(item_indices).to(self.dev))
#         logits = item_embs.matmul(final_feat.unsqueeze(-1)).squeeze(-1)
#         return logits
class SASRec(nn.Module):
    def __init__(self, user_num, item_num, args):
        super().__init__()
        self.item_num = item_num
        self.dev = args.device

        # Embedding layers
        self.item_emb = nn.Embedding(item_num + 1, args.hidden_units, padding_idx=0)
        self.pos_emb = nn.Embedding(args.maxlen + 1, args.hidden_units, padding_idx=0)
        self.emb_dropout = nn.Dropout(p=args.dropout_rate)

        # Precompute position indices buffer (so we don't build ranges every forward)
        pos_idxs = torch.arange(args.maxlen, dtype=torch.long).unsqueeze(0) + 1  # [1, L]
        self.register_buffer("pos_idxs", pos_idxs)  # moved to device with model

        # Transformer blocks
        self.attention_layernorms = nn.ModuleList()
        self.attention_layers = nn.ModuleList()
        self.forward_layernorms = nn.ModuleList()
        self.forward_layers = nn.ModuleList()

        for _ in range(args.num_blocks):
            self.attention_layernorms.append(nn.LayerNorm(args.hidden_units, eps=1e-12))
            # use the optimized linear attention
            self.attention_layers.append(LinearAttention(args.hidden_units, args.num_heads, args.dropout_rate, chunk_size=64))
            self.forward_layernorms.append(nn.LayerNorm(args.hidden_units, eps=1e-12))
            self.forward_layers.append(PointWiseFeedForward(args.hidden_units, args.dropout_rate))

        self.last_layernorm = nn.LayerNorm(args.hidden_units, eps=1e-12)

    def log2feats(self, log_seqs):
        """
        Expect log_seqs to be a torch.LongTensor already on the correct device (no numpy conversions).
        log_seqs: [B, L] LongTensor on self.dev
        """
        log_seqs = torch.from_numpy(log_seqs).long().to(self.dev)
        # assume inputs are tensors (no torch.from_numpy)
        seqs = self.item_emb(log_seqs.to(self.dev)) * (self.item_emb.embedding_dim ** 0.5)

        # positional embeddings: use registered buffer
        B = log_seqs.size(0)
        positions = self.pos_idxs.expand(B, -1).to(self.dev)  # [B, L]
        seqs = seqs + self.pos_emb(positions)

        seqs = self.emb_dropout(seqs)

        # Transformer blocks (pre-norm)
        for ln1, attn, ln2, fwd in zip(
            self.attention_layernorms, self.attention_layers,
            self.forward_layernorms, self.forward_layers
        ):
            seqs = ln1(seqs)
            seqs = attn(seqs)  # causal linear attention
            seqs = ln2(seqs)
            seqs = fwd(seqs)

        return self.last_layernorm(seqs)

    # forward and predict should also expect tensors on device (no numpy conversions)
    def forward(self, user_ids, log_seqs, pos_seqs, neg_seqs):
        # user_ids, log_seqs, pos_seqs, neg_seqs MUST be torch tensors on self.dev
        log_feats = self.log2feats(log_seqs)

        pos_seqs = torch.from_numpy(pos_seqs).long().to(self.dev)
        neg_seqs = torch.from_numpy(neg_seqs).long().to(self.dev)
        pos_embs = self.item_emb(pos_seqs.to(self.dev))
        neg_embs = self.item_emb(neg_seqs.to(self.dev))

        pos_logits = (log_feats * pos_embs).sum(dim=-1)
        neg_logits = (log_feats * neg_embs).sum(dim=-1)
        return pos_logits, neg_logits

    def predict(self, user_ids, log_seqs, item_indices):
        log_feats = self.log2feats(log_seqs)
        final_feat = log_feats[:, -1, :]
        item_embs = self.item_emb(torch.LongTensor(item_indices).to(self.dev))
        logits = item_embs.matmul(final_feat.unsqueeze(-1)).squeeze(-1)
        return logits


# """Trying another version"""
# import torch
# import torch.nn as nn
# import torch.nn.functional as F


# class LinearAttention(nn.Module):
#     """
#     Chunked causal linear attention with feature-projection (no D x D full matrices).
#     Processes sequence in chunks to limit peak memory usage.

#     Args:
#       hidden_units: total hidden dims (C)
#       num_heads: number of heads (H)
#       dropout_rate: dropout after out_proj
#       kernel_dim: projection dim m (recommend 32..128)
#       chunk_size: process sequence in blocks of chunk_size
#     """
#     def __init__(self, hidden_units, num_heads, dropout_rate, kernel_dim=64, chunk_size=64, eps=1e-6):
#         super().__init__()
#         assert hidden_units % num_heads == 0
#         self.C = hidden_units
#         self.H = num_heads
#         self.D = hidden_units // num_heads
#         self.m = kernel_dim
#         self.chunk_size = chunk_size
#         self.eps = eps

#         # projections
#         self.to_q = nn.Linear(self.C, self.C, bias=False)
#         self.to_k = nn.Linear(self.C, self.C, bias=False)
#         self.to_v = nn.Linear(self.C, self.C, bias=False)

#         # small per-head projection from D -> m
#         self.q_proj = nn.Linear(self.D, self.m, bias=False)
#         self.k_proj = nn.Linear(self.D, self.m, bias=False)

#         self.out_proj = nn.Linear(self.C, self.C)
#         self.dropout = nn.Dropout(dropout_rate)

#         self._phi = lambda x: F.elu(x) + 1.0

#     def forward(self, x, attention_mask=None):
#         # x: [B, L, C]
#         B, L, C = x.shape
#         H, D, m = self.H, self.D, self.m
#         device = x.device
#         dtype = x.dtype

#         # project Q,K,V -> [B, H, L, D]
#         q = self.to_q(x).view(B, L, H, D).permute(0, 2, 1, 3).contiguous()
#         k = self.to_k(x).view(B, L, H, D).permute(0, 2, 1, 3).contiguous()
#         v = self.to_v(x).view(B, L, H, D).permute(0, 2, 1, 3).contiguous()

#         # optional mask: [B, L] -> [B, 1, L, 1]
#         if attention_mask is not None:
#             mask = attention_mask.view(B, 1, L, 1).to(dtype)
#         else:
#             mask = None

#         # accumulators (S_kv: [B,H,m,D], S_k: [B,H,m])
#         S_kv = torch.zeros(B, H, m, D, device=device, dtype=dtype)
#         S_k  = torch.zeros(B, H, m, device=device, dtype=dtype)

#         outputs = []
#         # process in chunks along L
#         for start in range(0, L, self.chunk_size):
#             end = min(start + self.chunk_size, L)
#             q_chunk = q[:, :, start:end, :]   # [B,H,chunk,D]
#             k_chunk = k[:, :, start:end, :]   # [B,H,chunk,D]
#             v_chunk = v[:, :, start:end, :]   # [B,H,chunk,D]
#             chunk_len = end - start

#             # phi projections: shape [B,H,chunk,m]
#             q_feat = self._phi(self.q_proj(q_chunk))  # [B,H,chunk,m]
#             k_feat = self._phi(self.k_proj(k_chunk))  # [B,H,chunk,m]

#             if mask is not None:
#                 mask_chunk = mask[:, :, start:end, :]  # [B,1,chunk,1]
#                 k_feat = k_feat * mask_chunk
#                 v_chunk = v_chunk * mask_chunk

#             # Build kv_outer for this chunk: [B,H,chunk,m,D]
#             # compute phi_k.unsqueeze(-1) * v.unsqueeze(-2)
#             kv_chunk = k_feat.unsqueeze(-1) * v_chunk.unsqueeze(-2)

#             # cumsum within chunk to produce per-position prefix sums **including previous accumulator**
#             # cumulative along chunk dim:
#             kv_chunk_cumsum = kv_chunk.cumsum(dim=2)   # [B,H,chunk,m,D]
#             k_chunk_cumsum  = k_feat.cumsum(dim=2)     # [B,H,chunk,m]

#             # Add previous global accumulator to each position in chunk
#             # S_kv is [B,H,m,D] -> expand to [B,H,chunk,m,D]
#             kv_chunk_cumsum = kv_chunk_cumsum + S_kv.unsqueeze(2)
#             k_chunk_cumsum  = k_chunk_cumsum  + S_k.unsqueeze(2)

#             # numerator = einsum over m of q_feat * kv_chunk_cumsum -> [B,H,chunk,D]
#             # Use torch.einsum for batched contraction
#             num = torch.einsum('bhlm,bhlmd->bhld', q_feat, kv_chunk_cumsum)

#             # denom = q_feat dot k_chunk_cumsum -> [B,H,chunk,1]
#             denom = torch.einsum('bhlm,bhlm->bhl', q_feat, k_chunk_cumsum).unsqueeze(-1)

#             # context chunk: [B,H,chunk,D]
#             context_chunk = num / (denom + self.eps)

#             # update S_kv and S_k to include full chunk sums (for next chunk)
#             # last position cumulative in chunk is kv_chunk_cumsum[:, :, -1, :, :] which already includes S_kv
#             S_kv = kv_chunk_cumsum[:, :, -1, :, :].view(B, H, m, D)
#             S_k  = k_chunk_cumsum[:, :, -1, :].view(B, H, m)

#             # merge heads to [B, chunk, C]
#             context_chunk = context_chunk.permute(0, 2, 1, 3).contiguous().view(B, chunk_len, C)

#             outputs.append(context_chunk)

#         # concat along sequence dim
#         context = torch.cat(outputs, dim=1)  # [B, L, C]
#         out = self.out_proj(context)
#         out = self.dropout(out)
#         return x + out


# class PointWiseFeedForward(nn.Module):
#     def __init__(self, hidden_units, dropout_rate, intermediate_units=None):
#         super(PointWiseFeedForward, self).__init__()
#         if intermediate_units is None:
#             intermediate_units = hidden_units * 4
#         self.fc1 = nn.Linear(hidden_units, intermediate_units)
#         self.activation = nn.ReLU()
#         self.dropout = nn.Dropout(dropout_rate)
#         self.fc2 = nn.Linear(intermediate_units, hidden_units)

#     def forward(self, x):
#         residual = x
#         out = self.fc1(x)
#         out = self.activation(out)
#         out = self.dropout(out)
#         out = self.fc2(out)
#         out = self.dropout(out)
#         return out + residual


# class SASRec(nn.Module):
#     def __init__(self, user_num, item_num, args):
#         super(SASRec, self).__init__()
#         self.item_num = item_num
#         self.dev = args.device

#         # Embedding layers
#         self.item_emb = nn.Embedding(item_num + 1, args.hidden_units, padding_idx=0)
#         self.pos_emb = nn.Embedding(args.maxlen + 1, args.hidden_units, padding_idx=0)
#         self.emb_dropout = nn.Dropout(p=args.dropout_rate)

#         # Transformer blocks
#         self.attention_layernorms = nn.ModuleList()
#         self.attention_layers = nn.ModuleList()
#         self.forward_layernorms = nn.ModuleList()
#         self.forward_layers = nn.ModuleList()

#         for _ in range(args.num_blocks):
#             self.attention_layernorms.append(nn.LayerNorm(args.hidden_units, eps=1e-12))
#             self.attention_layers.append(LinearAttention(args.hidden_units, args.num_heads, args.dropout_rate))
#             self.forward_layernorms.append(nn.LayerNorm(args.hidden_units, eps=1e-12))
#             self.forward_layers.append(PointWiseFeedForward(args.hidden_units, args.dropout_rate))

#         self.last_layernorm = nn.LayerNorm(args.hidden_units, eps=1e-12)

#     def log2feats(self, log_seqs):
#         # Convert numpy to tensor and move to device
#         log_seqs = torch.from_numpy(log_seqs).long().to(self.dev)
#         seqs = self.item_emb(log_seqs) * (self.item_emb.embedding_dim ** 0.5)

#         # Positional encoding: sequential positions 1..L
#         positions = torch.arange(log_seqs.size(1), device=self.dev).unsqueeze(0).expand(log_seqs.size(0), -1) + 1
#         seqs = seqs + self.pos_emb(positions)
#         seqs = self.emb_dropout(seqs)

#         # Transformer blocks
#         for ln1, attn, ln2, fwd in zip(
#             self.attention_layernorms, self.attention_layers,
#             self.forward_layernorms, self.forward_layers
#         ):
#             seqs = ln1(seqs)
#             seqs = attn(seqs)  # causal linear attention
#             seqs = ln2(seqs)
#             seqs = fwd(seqs)

#         return self.last_layernorm(seqs)


#     def forward(self, user_ids, log_seqs, pos_seqs, neg_seqs):
#         log_feats = self.log2feats(log_seqs)

#         pos_seqs = torch.from_numpy(pos_seqs).long().to(self.dev)
#         neg_seqs = torch.from_numpy(neg_seqs).long().to(self.dev)

        

#         pos_embs = self.item_emb(pos_seqs)
#         neg_embs = self.item_emb(neg_seqs)

#         pos_logits = (log_feats * pos_embs).sum(dim=-1)
#         neg_logits = (log_feats * neg_embs).sum(dim=-1)
#         return pos_logits, neg_logits

#     def predict(self, user_ids, log_seqs, item_indices):
#         log_feats = self.log2feats(log_seqs)
#         final_feat = log_feats[:, -1, :]
#         item_embs = self.item_emb(torch.LongTensor(item_indices).to(self.dev))
#         logits = item_embs.matmul(final_feat.unsqueeze(-1)).squeeze(-1)
#         return logits    
